package cz.vutbr.feec.utko.bpcmds.du2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Du2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
